# DO NOT EDIT. AUTOMATICALLY GENERATED.

src/bb.lo: src/bb.c .make.dirs include/tcn.h include/tcn_api.h
src/error.lo: src/error.c .make.dirs include/tcn.h include/tcn_api.h
src/jnilib.lo: src/jnilib.c .make.dirs include/tcn.h include/tcn_api.h include/tcn_version.h
src/pool.lo: src/pool.c .make.dirs include/tcn.h include/tcn_api.h
src/ssl.lo: src/ssl.c .make.dirs include/ssl_private.h include/tcn.h include/tcn_api.h
src/sslconf.lo: src/sslconf.c .make.dirs include/ssl_private.h include/tcn.h include/tcn_api.h
src/sslcontext.lo: src/sslcontext.c .make.dirs include/ssl_private.h include/tcn.h include/tcn_api.h
src/sslutils.lo: src/sslutils.c .make.dirs include/ssl_private.h include/tcn.h include/tcn_api.h

OBJECTS_all = src/bb.lo src/error.lo src/jnilib.lo src/pool.lo src/ssl.lo src/sslconf.lo src/sslcontext.lo src/sslutils.lo

OBJECTS_unix = $(OBJECTS_all)

OBJECTS_aix = $(OBJECTS_all) $(OBJECTS_os_unix)

OBJECTS_beos = $(OBJECTS_all) $(OBJECTS_os_unix)

OBJECTS_os2 = $(OBJECTS_all) $(OBJECTS_os_unix)

OBJECTS_os390 = $(OBJECTS_all) $(OBJECTS_os_unix)

os/win32/system.lo: os/win32/system.c .make.dirs include/ssl_private.h include/tcn.h include/tcn_api.h

OBJECTS_os_win32 = os/win32/system.lo

OBJECTS_win32 = $(OBJECTS_all) $(OBJECTS_os_win32)

HEADERS = $(top_srcdir)/include/ssl_private.h $(top_srcdir)/include/tcn.h $(top_srcdir)/include/tcn_api.h $(top_srcdir)/include/tcn_version.h

SOURCE_DIRS = src os/win32 $(EXTRA_SOURCE_DIRS)

BUILD_DIRS = os os/win32 src

.make.dirs: $(srcdir)/build-outputs.mk
	@for d in $(BUILD_DIRS); do test -d $$d || mkdir $$d; done
	@echo timestamp > $@
